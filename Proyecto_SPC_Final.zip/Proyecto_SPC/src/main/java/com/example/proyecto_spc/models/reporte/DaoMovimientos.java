package com.example.proyecto_spc.models.reporte;
import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.models.usuario.Usuario;
import com.example.proyecto_spc.utils.MySQLConnection;
import jakarta.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoMovimientos implements DaoRepository<Movimientos> {
    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;
    private CallableStatement cstm;
    HttpSession session;

    @Override
    public List<Movimientos> findAll(Long id) {
        List<Movimientos> movimientos = new ArrayList<>();;
        try {
            conn = new MySQLConnection().connect();
            String query = "call ver_movs(?);";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, id);
            rs = cstm.executeQuery();
            while (rs.next()){
                Movimientos movimiento = new Movimientos();
                movimiento.setMonto(rs.getDouble("monto"));
                movimiento.setFecha(String.valueOf(rs.getDate("fecha")));
                movimiento.setConcepto(rs.getString("concepto"));
                movimiento.setId_reporte(rs.getLong("id_reporte"));
                movimiento.setTipo_movimiento(rs.getString("tipo_movimiento"));
                movimiento.setCuenta(rs.getString("numero_cuenta"));
                movimiento.setBanco(rs.getString("nombre_banco"));

                Categoria categoria = new Categoria();
                categoria.setId_categoria(rs.getLong("id_categoria"));
                categoria.setNombre(rs.getString("nombre_cat"));
                movimiento.setFk_categoria(categoria);

                /*Usuario usuario = new Usuario();
                usuario.setId_usuario(rs.getLong("id_usuario"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setCorreo(rs.getString("correo"));
                usuario.setContrasena(rs.getString("contrasena"));*/
                movimientos.add(movimiento);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error" + e.getMessage());
        }finally {
            close();
        }
        return movimientos;
    }

    @Override
    public Movimientos findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(Movimientos movimiento) {
        try {
            conn = new MySQLConnection().connect();
            String query = "call save_mov(?, ?, ?, ?, ?, ?, ?);";
            cstm = conn.prepareCall(query);
            cstm.setDouble(1, movimiento.getMonto());
            cstm.setString(2, movimiento.getFecha());
            cstm.setString(3, movimiento.getConcepto());
            cstm.setString(4, movimiento.getTipo_movimiento());
            cstm.setLong(5, movimiento.getFk_cuenta());
            cstm.setLong(6, movimiento.getId_cat());
            cstm.setLong(7, movimiento.getFk_usuarior().getId_usuario());

            return cstm.executeUpdate() > 0;
        } catch (SQLException e) {
            Logger.getLogger(DaoMovimientos.class.getName())
                    .log(Level.SEVERE, "Error save" + e.getMessage());
        } finally {
            close();
        }
        return false;
    }

    @Override
    public boolean update(Movimientos movimiento) {
        try {
            conn= new MySQLConnection().connect();
            String query = "call update_mov(?,?,?,?,?,?);";
            cstm = conn.prepareCall(query);
            cstm.setDouble(1, movimiento.getMonto());
            cstm.setString(2, movimiento.getFecha());
            cstm.setString(3, movimiento.getConcepto());
            cstm.setLong(4, movimiento.getId_cat());
            cstm.setLong(5, movimiento.getFk_cuenta2());
            cstm.setLong(6, movimiento.getId_reporte());

            return cstm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            close();
        }
    }

    @Override
    public boolean delete(Long movimientoId) {
        try {
            conn= new MySQLConnection().connect();
            String query = "call eliminar_mov(?);";
            cstm =conn.prepareCall(query);
            cstm.setLong(1, movimientoId);
            return cstm.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            close();
        }
    }

    public void close(){
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (cstm != null) cstm.close();
            if (rs != null) rs.close();
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }
}