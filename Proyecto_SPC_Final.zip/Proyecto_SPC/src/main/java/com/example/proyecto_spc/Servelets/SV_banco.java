package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.cuenta_usuario.DaoCuenta_Usuario;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "bancos",urlPatterns = {
        "/AñadirCB", "/cuenta/eliminar", "/cuenta/guardar", "/cuenta/update"
})

public class SV_banco extends HttpServlet {
    private String action, redirect, nombre, num_cuenta;
    private int id_cuenta_usuario;
    private Long userId, id_cuenta;
    private Usuario usuario;
    HttpSession session;
    boolean result;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");

        action = req.getServletPath();
        switch (action) {

        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");

        action = req.getServletPath();
        switch (action){
            case "/AñadirCB":

                break;
            case "/cuenta/eliminar":
                Long id = Long.parseLong(req.getParameter("id_cuenta"));

                result= new DaoCuenta_Usuario().delete(id);
                if(result){
                    redirect = "/SPC/Cuentas?result=" + true + "&message="
                            + URLEncoder.encode("Éxito! Cuenta eliminada correctamente",
                            StandardCharsets.UTF_8);
                } else {
                    redirect = "/SPC/Cuentas?result=" + false + "&message="
                            + URLEncoder.encode("Esta cuenta está siendo utilizada actualmente",
                            StandardCharsets.UTF_8);
                }
                break;

            case "/cuenta/update":
                session = req.getSession();
                 id_cuenta = Long.parseLong(req.getParameter("id_cuenta"));
                 nombre = req.getParameter("nombre");
                 num_cuenta = req.getParameter("num_cuenta");

                 usuario = (Usuario) session.getAttribute("user");
                 userId = usuario.getId_usuario();

                cuenta_usuario cuenta = new cuenta_usuario();
                cuenta.setId_cuenta_usuario(id_cuenta);
                cuenta.setNombre_banco(nombre);
                cuenta.setNumero_cuenta(num_cuenta);
                cuenta.setFk_id_usuario(userId);

                if(!new DaoCuenta_Usuario().update(cuenta)){
                    redirect = "/SPC/Cuentas?result=" + true + "&message="
                            + URLEncoder.encode("Éxito! Cuenta actualizada correctamente",
                            StandardCharsets.UTF_8);
                } else {
                    redirect = "/SPC/Cuentas?result=" + false + "&message="
                            + URLEncoder.encode("¡Error! Cuenta ya existe",
                            StandardCharsets.UTF_8);
                }
                break;
            case "/cuenta/guardar":
                session = req.getSession();
                nombre = req.getParameter("nombre");
                num_cuenta = req.getParameter("num_cuenta");

                usuario = (Usuario) session.getAttribute("user");
                userId = usuario.getId_usuario();

                cuenta_usuario cuenta_s = new cuenta_usuario();
                cuenta_s.setNombre_banco(nombre);
                cuenta_s.setNumero_cuenta(num_cuenta);
                cuenta_s.setFk_id_usuario(userId);

                if(!new DaoCuenta_Usuario().save(cuenta_s)){
                    redirect = "/SPC/Cuentas?result=" + true + "&message="
                            + URLEncoder.encode("Éxito! Cuenta registrada correctamente",
                            StandardCharsets.UTF_8);
                } else {
                    redirect = "/SPC/Cuentas?result=" + false + "&message="
                            + URLEncoder.encode("¡Error! Cuenta ya existe",
                            StandardCharsets.UTF_8);
                }
                break;

        }
        resp.sendRedirect(req.getContextPath() + redirect);
    }



}