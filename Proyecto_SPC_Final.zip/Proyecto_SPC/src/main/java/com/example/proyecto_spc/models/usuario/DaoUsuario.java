package com.example.proyecto_spc.models.usuario;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.utils.MySQLConnection;

import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoUsuario implements DaoRepository<Usuario> {
    private Connection conn;
    private PreparedStatement pstm;
    private CallableStatement cstm;
    private ResultSet rs;
    @Override
    public List<Usuario> findAll(Long id) {
        try{

        }catch (Exception e){
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE,"ERROR findAll"+e.getMessage());
        }finally {
            close();
        }
        return null;
    }

    @Override
    public Usuario findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(Usuario object) {
        try {
            conn = new MySQLConnection().connect();
            String query = "call save_user(?, ?, ?);";
            cstm = conn.prepareCall(query);
            cstm.setString(1, object.getCorreo());
            cstm.setString(2, object.getNombre());
            cstm.setString(3, object.getContrasena());

            return cstm.executeUpdate() > 0; // == 1
        } catch (SQLException e){
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, "Error a Registrar" + e.getMessage());
        } finally {
            close();
        }
        return false;
    }

    @Override
    public boolean update(Usuario object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
    public void close(){
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (rs != null) rs.close();
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }
    public Usuario autenticar(String correo, String contrasena) {
        try {
            conn = new MySQLConnection().connect();
            String query = "call ver_user(?,?)";
            cstm = conn.prepareCall(query);
            cstm.setString(1, correo);
            cstm.setString(2, contrasena);
            rs = cstm.executeQuery();

            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId_usuario(rs.getLong("id_usuario"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setCorreo(rs.getString("correo"));
                return usuario;
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, "Error en autenticación: " + e.getMessage());
        } finally {
            close();
        }
        return null;
    }
}
