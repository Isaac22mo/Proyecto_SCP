package com.example.proyecto_spc.models.registro_log;
import com.example.proyecto_spc.models.crud.DaoRepository;

import java.util.List;

public class DaoRegistro_log implements DaoRepository<registro_log> {
    @Override
    public List<registro_log> findAll(Long id) {
        return null;
    }

    @Override
    public registro_log findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(registro_log object) {
        return false;
    }

    @Override
    public boolean update(registro_log object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
}
