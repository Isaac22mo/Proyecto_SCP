package com.example.proyecto_spc.models.categoria;

public class Categoria {

    private Long id_categoria;
    private String nombre;
    private Long fk_Categoria;
    private boolean estado;

    public Categoria() {

    }

    public Categoria(String nombre, Long fk_Categoria, boolean estado) {
        this.nombre = nombre;
        this.fk_Categoria = fk_Categoria;
        this.estado = estado;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Long getFk_Categoria() {
        return fk_Categoria;
    }

    public void setFk_Categoria(Long fk_Categoria) {
        this.fk_Categoria = fk_Categoria;
    }

    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    public Categoria(Long id_categoria) {
        this.id_categoria = id_categoria;
    }

    public Long getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(Long id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
