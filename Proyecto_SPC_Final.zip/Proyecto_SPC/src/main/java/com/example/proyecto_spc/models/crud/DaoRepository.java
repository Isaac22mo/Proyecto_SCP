package com.example.proyecto_spc.models.crud;

import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;

import java.util.List;

public interface DaoRepository <T> {
    List<T> findAll(Long id);
    T findOne(Long id);
    boolean save(T object);
    boolean update(T object);
    boolean delete (Long id);

}
