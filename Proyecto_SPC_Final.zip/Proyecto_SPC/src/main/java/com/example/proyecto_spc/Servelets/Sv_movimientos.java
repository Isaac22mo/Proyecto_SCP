package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.cuenta_usuario.DaoCuenta_Usuario;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;
import com.example.proyecto_spc.models.reporte.DaoMovimientos;
import com.example.proyecto_spc.models.reporte.Movimientos;
import com.example.proyecto_spc.models.usuario.DaoUsuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@WebServlet(name = "movimientos", urlPatterns = {
        "/AñadirM", "/SPC/EliminarMovimiento", "/SPC/ActualizarMovimiento"
})
public class Sv_movimientos extends HttpServlet {
    private String action;
    private String redirect;
    private String nombre;
    HttpSession session;
    private Long id_reporte;
    private String monto;
    private String fecha;
    private String concepto;
    private String tipo_movimiento;
    private cuenta_usuario fk_cuenta_usuario;
    private String Id_categoria;
    private Long fk_uruarior;
    Movimientos movimiento;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        session = req.getSession();
        if (session.getAttribute("user") != null) {
            switch (action) {
                case "/AñadirM":
                    Usuario usuario = (Usuario) session.getAttribute("user");
                    Long userId = usuario.getId_usuario();

                    Movimientos movimientos = new Movimientos();
                    movimiento = new Movimientos();
                    movimiento.setMonto(Double.parseDouble(req.getParameter("monto")));
                    movimiento.setFecha(req.getParameter("fecha"));
                    movimiento.setConcepto(req.getParameter("concepto"));
                    movimiento.setTipo_movimiento(req.getParameter("tipo_movimiento"));
                    movimiento.setFk_usuarior(usuario);
                    movimiento.setFk_cuenta(Long.parseLong(req.getParameter("cuenta")));
                    String id_categoria = req.getParameter("categoria");
                    //Categoria categoria = new DaoCategoria().findOne(Long.parseLong(id_categoria));
                    movimiento.setId_cat(Long.parseLong(id_categoria));

                    boolean result = new DaoMovimientos().save(movimiento);
                    if (!result) {
                        redirect = "/SPC/Movimientos?result=" + true + "&message="
                                + URLEncoder.encode("Éxito! Movimiento registrado correctamente",
                                StandardCharsets.UTF_8);
                    } else {
                        redirect = "/SPC/Movimientos?result= " + false + "&message="
                                + URLEncoder.encode("¡Error! Acción no realizada correctamente",
                                StandardCharsets.UTF_8);
                    }
                    break;
                case "/SPC/ActualizarMovimiento":
                    /*String movimientoIdStr = req.getParameter("id_reporte");
                    if (movimientoIdStr != null && !movimientoIdStr.isEmpty()) {*/
                        try {
                            //Long movimientoId = Long.parseLong(movimientoIdStr);
                            Long movimientoId = Long.parseLong(req.getParameter("id_reporte"));
                            Double montoEditado = Double.parseDouble(req.getParameter("monto"));
                            String fechaEditada = req.getParameter("fecha");
                            String conceptoEditado = req.getParameter("concepto");
                            //String cuentaEditada = req.getParameter("fk_cuenta_usuario");

                            Usuario usuariomov = (Usuario) session.getAttribute("user");
                            Long cuentaEditada = usuariomov.getId_usuario();
                            Long categoriaIdEditada = Long.parseLong(req.getParameter("fk_categoria"));


                            Movimientos movimientoActualizado = new Movimientos();
                            movimientoActualizado.setId_reporte(movimientoId);
                            movimientoActualizado.setMonto(montoEditado);
                            movimientoActualizado.setFecha(fechaEditada);
                            movimientoActualizado.setConcepto(conceptoEditado);
                            movimientoActualizado.setId_cat(categoriaIdEditada);

                            // Aquí podrías configurar el objeto cuenta_usuario y Categoria si es necesario
                            /*if (cuentaEditada != null) {
                                Usuario usuarioCuenta = new Usuario(); // Crear una instancia de Usuario
                                usuarioCuenta.setId_usuario(cuentaEditada); // Establecer el ID de usuario
                                movimientoActualizado.setFk_cuenta_usuario(fk_cuenta_usuario);
                            }*/
                            movimientoActualizado.setFk_cuenta2(cuentaEditada);


                            boolean resultadoActualizacion = new DaoMovimientos().update(movimientoActualizado);

                            if (resultadoActualizacion) {
                                redirect = "/SPC/Movimientos?result=success&message=Movimiento+actualizado+exitosamente";
                            } else {
                                redirect = "/SPC/Movimientos?result=error&message=No+se+pudo+actualizar+el+movimiento";
                            }
                            // No realizar la redirección aquí
                            // performRedirect = false;
                        } catch (NumberFormatException e) {
                            redirect = "/SPC/Movimientos?result=error&message=ID+de+movimiento+no+válido";
                        }
                    /*} else {
                        redirect = "/SPC/Movimientos?result=error&message=ID+de+movimiento+no+especificado";
                    }*/
                    break;

                case "/SPC/EliminarMovimiento":
                    String eliminarMovimientoId = req.getParameter("id_movimiento");
                    String deleteResult;
                    try {
                        if (eliminarMovimientoId != null && !eliminarMovimientoId.isEmpty()) {
                            long id = Long.parseLong(eliminarMovimientoId);
                            boolean resultadoEliminacion = new DaoMovimientos().delete(id);
                            if (resultadoEliminacion) {
                                deleteResult = "success";
                                // No realizar la redirección aquí
                                // performRedirect = false;
                            } else {
                                deleteResult = "error";
                            }
                        } else {
                            // Manejar el caso de parámetro "id_movimiento" vacío o nulo
                            deleteResult = "error";
                        }
                    } catch (NumberFormatException e) {
                        // Manejar la excepción de conversión de cadena a número
                        deleteResult = "error";
                    }
                    redirect = "/SPC/Movimientos?result=" + deleteResult;
                    break;


            }
        }

        resp.sendRedirect(req.getContextPath() + redirect);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
