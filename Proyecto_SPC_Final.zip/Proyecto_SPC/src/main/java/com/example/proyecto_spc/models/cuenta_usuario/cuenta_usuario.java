package com.example.proyecto_spc.models.cuenta_usuario;

import com.example.proyecto_spc.models.usuario.Usuario;

public class cuenta_usuario {

    private Long id_cuenta_usuario, fk_id_usuario;
    private String nombre_banco;
    private String numero_cuenta;

    public cuenta_usuario() {
    }

    public cuenta_usuario(Long id_cuenta_usuario, String nombre_banco, String numero_cuenta, Long fk_id_usuario) {
        this.id_cuenta_usuario = id_cuenta_usuario;
        this.nombre_banco = nombre_banco;
        this.numero_cuenta = numero_cuenta;
        this.fk_id_usuario = fk_id_usuario;
    }

    public Long getId_cuenta_usuario() {
        return id_cuenta_usuario;
    }

    public void setId_cuenta_usuario(Long id_cuenta_usuario) {
        this.id_cuenta_usuario = id_cuenta_usuario;
    }

    public String getNombre_banco() {
        return nombre_banco;
    }

    public void setNombre_banco(String nombre_banco) {
        this.nombre_banco = nombre_banco;
    }

    public String getNumero_cuenta() {
        return numero_cuenta;
    }

    public void setNumero_cuenta(String numero_cuenta) {
        this.numero_cuenta = numero_cuenta;
    }

    public Long getFk_id_usuario() {
        return fk_id_usuario;
    }

    public void setFk_id_usuario(Long fk_id_usuario) {
        this.fk_id_usuario = fk_id_usuario;
    }
}
