package com.example.proyecto_spc.models.historial;


import com.example.proyecto_spc.models.reporte.Movimientos;

public class historial {

    private Long id_historial;
    private String fecha;
    private String reporte_mov;
    private Movimientos fk_reporte;

    public historial() {
    }

    public historial(Long id_historial, String fecha, String reporte_mov, Movimientos fk_reporte) {
        this.id_historial = id_historial;
        this.fecha = fecha;
        this.reporte_mov = reporte_mov;
        this.fk_reporte = fk_reporte;
    }

    public Long getId_historial() {

        return id_historial;
    }

    public void setId_historial(Long id_historial) {

        this.id_historial = id_historial;
    }

    public String getFecha() {

        return fecha;
    }

    public void setFecha(String fecha) {

        this.fecha = fecha;
    }

    public String getReporte_mov() {

        return reporte_mov;
    }

    public void setReporte_mov(String reporte_mov) {

        this.reporte_mov = reporte_mov;
    }

    public Movimientos getFk_reporte() {

        return fk_reporte;
    }

    public void setFk_reporte(Movimientos fk_reporte) {

        this.fk_reporte = fk_reporte;
    }
}
