package com.example.proyecto_spc.models.reporte;


import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;
import com.example.proyecto_spc.models.usuario.Usuario;

public class Movimientos {

    private Long id_reporte, id_cat, fk_cuenta, fk_cuenta2;
    private double monto;
    private String fecha;
    private String concepto;
    private String tipo_movimiento;
    private String cuenta;
    private String banco;
    private cuenta_usuario fk_cuenta_usuario;
    private Categoria fk_categoria;

    private Categoria categoria;
    private Usuario fk_usuarior;


    public Movimientos() {
    }

    public Movimientos(Long id_reporte, double monto, String fecha, String concepto, String tipo_movimiento, cuenta_usuario fk_cuenta_usuario, Categoria fk_categoria, Usuario fk_usuarior) {
        this.id_reporte = id_reporte;
        this.monto = monto;
        this.fecha = fecha;
        this.concepto = concepto;
        this.tipo_movimiento = tipo_movimiento;
        this.fk_cuenta_usuario = fk_cuenta_usuario;
        this.fk_categoria = fk_categoria;
        this.fk_usuarior = fk_usuarior;
    }

    public Movimientos(Long id_reporte, double monto, String fecha, String concepto, String tipo_movimiento, Long fk_cuenta_usuario, Long fk_categoria, Long fk_usuarior, String cuenta, String banco) {
        this.id_reporte = id_reporte;
        this.monto = monto;
        this.fecha = fecha;
        this.concepto = concepto;
        this.tipo_movimiento = tipo_movimiento;
        this.fk_cuenta = fk_cuenta_usuario;
        this.id_cat = fk_categoria;
        this.fk_cuenta2 = fk_usuarior;
        this.cuenta = cuenta;
        this.banco = banco;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public Long getFk_cuenta() {
        return fk_cuenta;
    }

    public void setFk_cuenta(Long fk_cuenta) {
        this.fk_cuenta = fk_cuenta;
    }

    public Long getFk_cuenta2() {
        return fk_cuenta2;
    }

    public void setFk_cuenta2(Long fk_cuenta2) {
        this.fk_cuenta2 = fk_cuenta2;
    }

    public Long getId_cat() {
        return id_cat;
    }

    public void setId_cat(Long id_cat) {
        this.id_cat = id_cat;
    }

    public Long getId_reporte() {
        return id_reporte;
    }

    public void setId_reporte(Long id_reporte) {
        this.id_reporte = id_reporte;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public String getTipo_movimiento() {
        return tipo_movimiento;
    }

    public void setTipo_movimiento(String tipo_movimiento) {
        this.tipo_movimiento = tipo_movimiento;
    }

    public cuenta_usuario getFk_cuenta_usuario() {
        return fk_cuenta_usuario;
    }

    public void setFk_cuenta_usuario(cuenta_usuario fk_cuenta_usuario) {
        this.fk_cuenta_usuario = fk_cuenta_usuario;
    }

    public Categoria getFk_categoria() {
        return fk_categoria;
    }

    public void setFk_categoria(Categoria fk_categoria) {
        this.fk_categoria = fk_categoria;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Usuario getFk_usuarior() {
        return fk_usuarior;
    }

    public void setFk_usuarior(Usuario fk_usuarior) {
        this.fk_usuarior = fk_usuarior;
    }
}
