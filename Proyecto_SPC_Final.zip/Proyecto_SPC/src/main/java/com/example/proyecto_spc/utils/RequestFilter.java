package com.example.proyecto_spc.utils;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebFilter(urlPatterns = {"/SPC/*"})
public class RequestFilter implements Filter {

    List<String> whiteList = new ArrayList<>();

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //Todos los links que NO requieren inicio de sesion
        // si no funcionan agregale "  /user  " antes
        whiteList.add("/Inicio");
        whiteList.add("/SPC/Registro");
        whiteList.add("/index.jsp");
        whiteList.add("/404");
    }

    @Override
    public void doFilter(ServletRequest servletRequest,
                         ServletResponse servletResponse,
                         FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String action = request.getServletPath();
        if (whiteList.contains(action)) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            HttpSession session = request.getSession(); //request.getSession es lo que te comenté de comprobar la informacion del inicio de sesion
            if (session.getAttribute("user") != null) { //el getSession va con el atributo Usuario y si es diferente a null, no hace nada
                filterChain.doFilter(servletRequest, servletResponse);
            } else {
                response.sendRedirect(request.getContextPath() + "/Inicio"); //si es null entonces redirecciona a la pagina para iniciar sesion
            }
        }
    }

    @Override
    public void destroy() {

    }
}
