package com.example.proyecto_spc.models.categoria;


import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.models.usuario.Usuario;
import com.example.proyecto_spc.utils.MySQLConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


public class DaoCategoria implements DaoRepository<Categoria> {

    private Connection conn;
    private PreparedStatement pstm;
    private CallableStatement cstm;
    private ResultSet rs;
    HttpSession session;

    @Override
    public List<Categoria> findAll(Long idUsuario) {
        List<Categoria> categorias = new ArrayList<>();
        try {
            conn = new MySQLConnection().connect();
            String query = "call ver_cat(?)";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, idUsuario);
            rs = cstm.executeQuery();
            while (rs.next()){
                Categoria categoria = new Categoria();
                categoria.setId_categoria(rs.getLong("id_categoria"));
                categoria.setNombre(rs.getString("nombre_cat"));
                categoria.setEstado(rs.getBoolean("estado"));
                categorias.add(categoria);
            }
        } catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error" + e.getMessage());
        } finally {
            close();
        }
        return categorias;
    }

    @Override
    public Categoria findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(Categoria object) {
        try {
            conn = new MySQLConnection().connect();
            String query = "call save_categoria(?,true,?);";
            cstm = conn.prepareCall(query);
            cstm.setString(1, object.getNombre());
            cstm.setLong(2, object.getFk_Categoria());
            return cstm.executeUpdate()  == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName()).log(Level.SEVERE, "Error save" + e.getMessage());

        } finally {
            close();
        }
        return false;
    }

    @Override
    public boolean update(Categoria object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        try {
            conn = new MySQLConnection().connect();
            String query = "CALL eliminar_cat(?);";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, id);
            return cstm.executeUpdate() == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName()).log(Level.SEVERE, "Error delete" + e.getMessage());
            return false;
        } finally {
            close();
        }

    }

    public boolean desactivar(Long id) {
        try {
            conn = new MySQLConnection().connect();
            String query = "CALL desactivar(?);";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, id);
            return cstm.executeUpdate() == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName()).log(Level.SEVERE, "Error save" + e.getMessage());
            return false;
        } finally {
            close();
        }
    }

    public boolean activar(Long id) {
        try {
            conn = new MySQLConnection().connect();
            String query = "CALL activar(?);";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, id);
            return cstm.executeUpdate() == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName()).log(Level.SEVERE, "Error save" + e.getMessage());
            return false;
        } finally {
            close();
        }
    }

    public void close(){
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (cstm != null) cstm.close();
            if (rs != null) rs.close();
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }
}
