package com.example.proyecto_spc.models.cuenta_usuario;
import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.crud.DaoRepository;

import java.util.List;
import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.models.usuario.DaoUsuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import com.example.proyecto_spc.utils.MySQLConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.http.HttpSession;


public class DaoCuenta_Usuario implements DaoRepository<cuenta_usuario> {

    private Connection conn;
    private PreparedStatement pstm;
    private CallableStatement cstm;
    private ResultSet rs;

    @Override
    public List<cuenta_usuario> findAll(Long id) {
        List<cuenta_usuario> cuentas = new ArrayList<>();
        try {
            conn = new MySQLConnection().connect();
            String query = "CALL ver_bancos(?, null);";
            cstm = conn.prepareCall(query);
            cstm.setLong(1, id);
            rs = cstm.executeQuery();
            while (rs.next()) {
                cuenta_usuario cuenta = new cuenta_usuario();
                cuenta.setId_cuenta_usuario(rs.getLong("id_cuenta_usuario"));
                cuenta.setNombre_banco(rs.getString("nombre_banco"));
                cuenta.setNumero_cuenta(rs.getString("numero_cuenta"));
                cuentas.add(cuenta);
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoCuenta_Usuario.class.getName())
                    .log(Level.SEVERE, "Error" + e.getMessage());
        } finally {
            close();
        }
        return cuentas;
    }

    @Override
    public cuenta_usuario findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(cuenta_usuario cuenta) {
        try {
            conn = new MySQLConnection().connect();
            String query = "CALL save_cuenta_bancaria(?, ?, ?);";
            cstm = conn.prepareCall(query);
            cstm.setString(1, cuenta.getNombre_banco());
            cstm.setString(2, cuenta.getNumero_cuenta());
            cstm.setLong(3, cuenta.getFk_id_usuario());
            return cstm.executeUpdate() > 0;
        } catch (SQLException e) {
            Logger.getLogger(DaoCuenta_Usuario.class.getName()).log(Level.SEVERE, "Error save" + e.getMessage());
            return false;
        } finally {
            close();
        }
    }

    @Override
    public boolean update(cuenta_usuario cuenta) {
        try {
            conn= new MySQLConnection().connect();
            String query = "call editar_cuenta_banco(?,?,?,?);";
            cstm = conn.prepareCall(query);
            cstm.setString(1, cuenta.getNombre_banco());
            cstm.setString(2, cuenta.getNumero_cuenta());
            cstm.setLong(3, cuenta.getId_cuenta_usuario());
            cstm.setLong(4, cuenta.getFk_id_usuario());
            return cstm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            close();
        }
    }

    @Override
    public boolean delete(Long id) {
        try {
            conn= new MySQLConnection().connect();
            String query = "CALL eliminar_cuenta(?);";
            cstm =conn.prepareCall(query);
            cstm.setLong(1, id);
            return cstm.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            close();
        }
    }


    public void close() {
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (cstm != null) cstm.close();
            if (rs != null) rs.close();
        } catch (SQLException e) {
            Logger.getLogger(DaoCuenta_Usuario.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }

    public cuenta_usuario Cuenta_UsuarioUserId(Long userId) {
        cuenta_usuario cuentaUsuario = null;
        try {
            conn = new MySQLConnection().connect();
            String query = "SELECT * FROM cuenta_usuario WHERE fk_id_usuario = ?;";
            pstm = conn.prepareStatement(query);
            pstm.setLong(1, userId);
            rs = pstm.executeQuery();
            if (rs.next()) {
                cuentaUsuario = new cuenta_usuario();
                cuentaUsuario.setId_cuenta_usuario(rs.getLong("id_cuenta_usuario"));
                cuentaUsuario.setNombre_banco(rs.getString("nombre_banco"));
                cuentaUsuario.setNumero_cuenta(rs.getString("numero_cuenta"));
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoCuenta_Usuario.class.getName())
                    .log(Level.SEVERE, "Error" + e.getMessage());
        } finally {
            close();
        }
        return cuentaUsuario;
    }
}