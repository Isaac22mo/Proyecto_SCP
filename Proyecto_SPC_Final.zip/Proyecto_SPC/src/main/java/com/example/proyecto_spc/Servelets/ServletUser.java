package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.cuenta_usuario.DaoCuenta_Usuario;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;
import com.example.proyecto_spc.models.usuario.DaoUsuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet(name = "users", urlPatterns = {
        "/user/users","/Registrar","/sesion",
})

public class ServletUser extends HttpServlet {
    private String action;
    private String redirect;

    Usuario user;
    private String nombre;
    private String correo;
    private String contrasena;

    HttpSession session;

    /*Request son las peticiones hechas por el usuario
     * Response son lo que se le eviara al usuario*/
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action) {
            case "/sesion":
                correo = req.getParameter("correo");
                contrasena = req.getParameter("contra");
                user = new DaoUsuario().autenticar(correo, contrasena);
                if (user != null) {
                    session = req.getSession();
                    session.setAttribute("user", user);

                    // Obtener la cuenta de usuario y guardarla en la sesión
                    cuenta_usuario cuentaUsuario = new DaoCuenta_Usuario().Cuenta_UsuarioUserId(user.getId_usuario());
                    if (cuentaUsuario != null) {
                        session.setAttribute("cuentaUsuario", cuentaUsuario);
                    }
                    redirect = "/SPC/Dashboard";
                } else {
                    redirect = "/Inicio?result=" + false + "&message="
                            + URLEncoder.encode("error", StandardCharsets.UTF_8);
                }
                break;
            case "/Registrar":
                correo= req.getParameter("correo");
                nombre= req.getParameter("nombre");
                contrasena= req.getParameter("contra");

                user = new Usuario(correo, nombre, contrasena);
                boolean result = new DaoUsuario().save(user);
                if (!result) {
                    redirect = "/Inicio";
                } else {
                    redirect = "/SPC/Registro?result=" + false + "&message="
                            + URLEncoder.encode("¡Error! La acción no se logró completar",
                            StandardCharsets.UTF_8);
                }
                break;
        }
        resp.sendRedirect(req.getContextPath() + redirect);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
