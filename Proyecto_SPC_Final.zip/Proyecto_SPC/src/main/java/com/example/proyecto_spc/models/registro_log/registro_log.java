package com.example.proyecto_spc.models.registro_log;

public class registro_log {

    private Long id_registro_log;
    private String tabla_afectada;
    private String accion;
    private String fecha_cambio;

    public registro_log() {
    }

    public registro_log(Long id_registro_log, String tabla_afectada, String accion, String fecha_cambio) {
        this.id_registro_log = id_registro_log;
        this.tabla_afectada = tabla_afectada;
        this.accion = accion;
        this.fecha_cambio = fecha_cambio;
    }

    public Long getId_registro_log() {

        return id_registro_log;
    }

    public void setId_registro_log(Long id_registro_log) {

        this.id_registro_log = id_registro_log;
    }

    public String getTabla_afectada() {
        return tabla_afectada;
    }

    public void setTabla_afectada(String tabla_afectada) {
        this.tabla_afectada = tabla_afectada;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getFecha_cambio() {
        return fecha_cambio;
    }

    public void setFecha_cambio(String fecha_cambio) {
        this.fecha_cambio = fecha_cambio;
    }
}
