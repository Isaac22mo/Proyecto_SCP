package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.cuenta_usuario.DaoCuenta_Usuario;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;
import com.example.proyecto_spc.models.reporte.DaoMovimientos;
import com.example.proyecto_spc.models.reporte.Movimientos;
import com.example.proyecto_spc.models.usuario.DaoUsuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@WebServlet(name = "categorias", urlPatterns = {
        "/SPC/Categorias","/Añadir","/SPC/Graficos","/SPC/Movimientos","/SPC/Dashboard","/Inicio","/SPC/Registro","/404",
        "/categoria/desactivar", "/categoria/activar", "/categoria/eliminar", "/SPC/Cuentas"
})
public class Sv_categoria extends HttpServlet {

    private Long id_categoria;
    Usuario user;
    private String nombre;
    private String action;
    private String redirect;
    Categoria categoria;
    HttpSession session;
    boolean result;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();

        session = req.getSession();
        if (session.getAttribute("user") != null) {
            switch (action) {
                case "/Añadir":
                    Usuario usuario = (Usuario) session.getAttribute("user");
                    Long userId = usuario.getId_usuario();

                    nombre = req.getParameter("nombre");
                    Categoria categoria = new Categoria(nombre);
                    categoria.setFk_Categoria(userId); // Asignar el ID de usuario a la categoría

                    result = new DaoCategoria().save(categoria);
                    if (result) {
                        redirect = "/SPC/Categorias?result=" + true + "&message="
                                + URLEncoder.encode("Éxito! Categoría registrada correctamente",
                                StandardCharsets.UTF_8);
                    } else {
                        redirect = "/SPC/Categorias?result=" + false + "&message="
                                + URLEncoder.encode("¡Error! Categoria ya existe",
                                StandardCharsets.UTF_8);
                    }
                    break;

                case "/categoria/desactivar":
                    Long id = Long.parseLong(req.getParameter("id_cat"));

                    result = new DaoCategoria().desactivar(id);
                    if(result){
                        redirect = "/SPC/Categorias?result=" + true + "&message="
                                + URLEncoder.encode("Éxito! Categoría desactivada correctamente",
                                StandardCharsets.UTF_8);
                    } else {
                        redirect = "/SPC/Categorias?result=" + false + "&message="
                                + URLEncoder.encode("¡Error! Acción no realizada correctamente",
                                StandardCharsets.UTF_8);
                    }
                    break;

                case "/categoria/activar":
                    Long id2 = Long.parseLong(req.getParameter("id"));

                    result = new DaoCategoria().activar(id2);
                    if(result){
                        redirect = "/SPC/Categorias?result=" + true + "&message="
                                + URLEncoder.encode("Éxito! Categoría activada correctamente",
                                StandardCharsets.UTF_8);
                    } else {
                        redirect = "/SPC/Categorias?result=" + false + "&message="
                                + URLEncoder.encode("¡Error! Acción no realizada correctamente",
                                StandardCharsets.UTF_8);
                    }
                    break;

                case "/categoria/eliminar":
                    Long id3= Long.parseLong(req.getParameter("id"));
                    result= new DaoCategoria().delete(id3);
                    if(result){
                        redirect = "/SPC/Categorias?result=" + true + "&message="
                                + URLEncoder.encode("Éxito! Categoría eliminada correctamente",
                                StandardCharsets.UTF_8);
                    } else {
                        redirect = "/SPC/Categorias?result=" + false + "&message="
                                + URLEncoder.encode("Esta categoría está siendo utilizada actualmente",
                                StandardCharsets.UTF_8);
                    }
                    break;
            }
        } else {
            redirect = "/Inicio";
        }

        resp.sendRedirect(req.getContextPath() + redirect);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();

        session = req.getSession();
        try {
            switch (action) {

                case "/SPC/Cuentas":
                    session = req.getSession();
                    Usuario usuarioB = (Usuario) session.getAttribute("user");
                    Long userIdB = usuarioB.getId_usuario();

                    List<cuenta_usuario> cuentas = new DaoCuenta_Usuario().findAll(userIdB);
                    req.setAttribute("cuentas", cuentas);

                    redirect="/views/CuentasB.jsp";
                    break;

                case "/SPC/Categorias":
                    Usuario usuario = (Usuario) session.getAttribute("user");
                    Long userId = usuario.getId_usuario();

                    List<Categoria> categorias = new DaoCategoria().findAll(userId);
                    req.setAttribute("categorias", categorias);

                    redirect = "/views/Categorias.jsp";
                    break;

                case "/SPC/Dashboard":
                    redirect = "/views/Dashboard.jsp";
                    break;

                case "/SPC/Graficos":
                    redirect = "/views/Graficos.jsp";
                    break;
                case "/SPC/Movimientos":
                    Usuario usuariomov = (Usuario) session.getAttribute("user");
                    Long userIdmov = usuariomov.getId_usuario();

                    List<Movimientos> mov = new DaoMovimientos().findAll(userIdmov);
                    List<Categoria> categoria = new DaoCategoria().findAll(userIdmov);
                    List<cuenta_usuario> cuentas_All = new DaoCuenta_Usuario().findAll(userIdmov);
                    req.setAttribute("cuentas", cuentas_All);
                    req.setAttribute("movimientos", mov);
                    req.setAttribute("categorias", categoria);

                    redirect= "/views/Movimientos.jsp";
                    break;

                case "/Inicio":
                    session.setAttribute("user", user);
                    redirect = "index.jsp";
                    break;

                case "/SPC/Registro":
                    session.setAttribute("user", user);
                    redirect = "/views/Registro.jsp";
                    break;

                default:
                    redirect = "/views/404.jsp";
                    break;
            }
        } catch (Exception e) {
                redirect="/views/404.jsp";
        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }
}