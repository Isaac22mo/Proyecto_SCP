package com.example.proyecto_spc.models.cuenta_usuario;

import com.example.proyecto_spc.models.usuario.Usuario;

public class cuenta_usuario {

    private Long id_cuenta_usuario;
    private String nombre_banco;
    private String num_cuenta;
    private Usuario fk_id_usuario;

    public cuenta_usuario() {
    }

    public cuenta_usuario(Long id_cuenta_usuario, String nombre_banco, String num_cuenta, Usuario fk_id_usuario) {
        this.id_cuenta_usuario = id_cuenta_usuario;
        this.nombre_banco = nombre_banco;
        this.num_cuenta = num_cuenta;
        this.fk_id_usuario = fk_id_usuario;
    }

    public Long getId_cuenta_usuario() {
        return id_cuenta_usuario;
    }

    public void setId_cuenta_usuario(Long id_cuenta_usuario) {
        this.id_cuenta_usuario = id_cuenta_usuario;
    }

    public String getNombre_banco() {
        return nombre_banco;
    }

    public void setNombre_banco(String nombre_banco) {
        this.nombre_banco = nombre_banco;
    }

    public String getNum_cuenta() {
        return num_cuenta;
    }

    public void setNum_cuenta(String num_cuenta) {
        this.num_cuenta = num_cuenta;
    }

    public Usuario getFk_id_usuario() {
        return fk_id_usuario;
    }

    public void setFk_id_usuario(Usuario fk_id_usuario) {
        this.fk_id_usuario = fk_id_usuario;
    }
}
