package com.example.proyecto_spc.models.historial;
import com.example.proyecto_spc.models.crud.DaoRepository;

import java.util.List;

public class DaoHistorial implements DaoRepository<historial> {
    @Override
    public List<historial> findAll() {
        return null;
    }

    @Override
    public historial findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(historial object) {
        return false;
    }

    @Override
    public boolean update(historial object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
}
