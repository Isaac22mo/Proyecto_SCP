package com.example.proyecto_spc.models.cuenta_usuario;
import com.example.proyecto_spc.models.crud.DaoRepository;

import java.util.List;

public class DaoCuenta_usuario implements DaoRepository<cuenta_usuario> {
    @Override
    public List<cuenta_usuario> findAll() {
        return null;
    }

    @Override
    public cuenta_usuario findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(cuenta_usuario object) {
        return false;
    }

    @Override
    public boolean update(cuenta_usuario object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
}
