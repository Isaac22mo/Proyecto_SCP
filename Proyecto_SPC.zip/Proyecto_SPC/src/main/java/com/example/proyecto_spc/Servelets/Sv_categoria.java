package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.usuario.DaoUsuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@WebServlet(name = "categorias", urlPatterns = {
        "/Categorias","/Añadir",
})
public class Sv_categoria extends HttpServlet {

    private Long id_categoria;
    private String nombre;
    private String action;
    private String redirect;
    Categoria categoria;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action){
            case "/Añadir":
                nombre= req.getParameter("nombre");
                categoria = new Categoria(nombre);
                System.out.println(nombre);
                boolean result = new DaoCategoria().save(categoria);
                if (result) {
                    redirect = "/user/users?result=" + true + "&message="
                            + URLEncoder.encode("Éxito! Usuario regsitrado correctamente",
                            StandardCharsets.UTF_8);
                }else {
                    redirect = "/user/users?result= " + false + "&message="
                            + URLEncoder.encode("¡Error! Acción no realizada correctamente",
                            StandardCharsets.UTF_8);
                }
        }
        resp.sendRedirect(req.getContextPath() + redirect);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action){
            case "/Categorias":
                List<Categoria> categorias =new DaoCategoria().findAll();
                req.setAttribute("categorias", categorias);
        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }
}
