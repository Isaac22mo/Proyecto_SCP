package com.example.proyecto_spc.models.categoria;


import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.utils.MySQLConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoCategoria implements DaoRepository<Categoria> {

    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;


    @Override
    public List<Categoria> findAll() {
        List<Categoria> categorias = null;
        try {
            categorias = new ArrayList<>();
            conn = new MySQLConnection().connect();
            String query = "Select * from categoria;";
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()){
                Categoria categoria = new Categoria();
                categoria.setNombre(rs.getString("nombre"));
                categorias.add(categoria);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error" + e.getMessage());
        }finally {
            close();
        }
        return categorias;
    }

    @Override
    public Categoria findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(Categoria object) {
        try {
            conn = new MySQLConnection().connect();
            String query = "INSERT INTO categoria (nombre)" + " VALUES (?);";
            pstm = conn.prepareStatement(query);
            pstm.setString(1, object.getNombre());
            return pstm.executeUpdate() > 0; // == 1
        } catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName()).log(Level.SEVERE, "Error save" + e.getMessage());
        } finally {
            close();
        }
        return false;
    }

    @Override
    public boolean update(Categoria object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }

    public void close(){
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (rs != null) rs.close();
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }

}
