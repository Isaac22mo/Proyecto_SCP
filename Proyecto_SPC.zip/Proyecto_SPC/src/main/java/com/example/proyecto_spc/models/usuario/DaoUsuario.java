package com.example.proyecto_spc.models.usuario;
import com.example.proyecto_spc.models.categoria.DaoCategoria;
import com.example.proyecto_spc.models.crud.DaoRepository;
import com.example.proyecto_spc.utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoUsuario implements DaoRepository<Usuario> {
    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;
    @Override
    public List<Usuario> findAll() {
        try{
            
        }catch (Exception e){
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE,"ERROR findAll"+e.getMessage());
        }finally {
            close();
        }
        return null;
    }

    @Override
    public Usuario findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(Usuario object) {
        try {
            conn = new MySQLConnection().connect();
            String query = "INSERT INTO usuario (nombre,correo, contrasena)" +
                    " VALUES (?, ?, ?);";
            pstm = conn.prepareStatement(query);
            pstm.setString(1, object.getNombre());
            pstm.setString(2, object.getCorreo());
            pstm.setString(3, object.getContrasena());

            return pstm.executeUpdate() > 0; // == 1
        } catch (SQLException e){
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, "Error a Registrar" + e.getMessage());
        } finally {
            close();
        }
        return false;
    }

    @Override
    public boolean update(Usuario object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
    public void close(){
        try {
            if (conn != null) conn.close();
            if (pstm != null) pstm.close();
            if (rs != null) rs.close();
        }catch (SQLException e){
            Logger.getLogger(DaoCategoria.class.getName())
                    .log(Level.SEVERE, "Error closeConnection" + e.getMessage());
        }
    }
}
