package com.example.proyecto_spc.Servelets;

import com.example.proyecto_spc.models.usuario.DaoUsuario;
import com.example.proyecto_spc.models.usuario.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet(name = "users", urlPatterns = {
        "/user/users","/Registrar","/sesion",
})

public class ServletUser extends HttpServlet {
    private String action;
    private String redirect;

    Usuario user;
    private String nombre;
    private String correo;
    private String contrasena;

    /*Request son las peticiones hechas por el usuario
     * Response son lo que se le eviara al usuario*/
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action){
            case "/sesion":
                redirect="/views/Dashboard.jsp";
                break;
            case "/Registrar":
                correo= req.getParameter("correo");
                nombre= req.getParameter("nombre");
                contrasena= req.getParameter("contra");

                user = new Usuario(correo, nombre, contrasena);
                boolean result = new DaoUsuario().save(user);
                if (result) {
                    redirect = "/user/users?result=" + true + "&message="
                            + URLEncoder.encode("Éxito! Usuario regsitrado correctamente",
                            StandardCharsets.UTF_8);
                }else {
                    redirect = "/user/users?result= " + false + "&message="
                            + URLEncoder.encode("¡Error! Acción no realizada correctamente",
                            StandardCharsets.UTF_8);
                }
                break;
        }
        resp.sendRedirect(req.getContextPath() + redirect);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
