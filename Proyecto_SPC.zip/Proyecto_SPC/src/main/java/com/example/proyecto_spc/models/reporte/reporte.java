package com.example.proyecto_spc.models.reporte;


import com.example.proyecto_spc.models.categoria.Categoria;
import com.example.proyecto_spc.models.cuenta_usuario.cuenta_usuario;

public class reporte {

    private Long id_reporte;
    private Long monto;
    private String fecha;
    private String concepto;
    private String tipo_movimiento;
    private cuenta_usuario fk_cuenta_usuario;
    private Categoria fk_categoria;

    public reporte() {
    }

    public reporte(Long id_reporte, Long monto, String fecha, String concepto, String tipo_movimiento, cuenta_usuario fk_cuenta_usuario, Categoria fk_categoria) {
        this.id_reporte = id_reporte;
        this.monto = monto;
        this.fecha = fecha;
        this.concepto = concepto;
        this.tipo_movimiento = tipo_movimiento;
        this.fk_cuenta_usuario = fk_cuenta_usuario;
        this.fk_categoria = fk_categoria;
    }

    public Long getId_reporte() {
        return id_reporte;
    }

    public void setId_reporte(Long id_reporte) {
        this.id_reporte = id_reporte;
    }

    public Long getMonto() {
        return monto;
    }

    public void setMonto(Long monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public String getTipo_movimiento() {
        return tipo_movimiento;
    }

    public void setTipo_movimiento(String tipo_movimiento) {
        this.tipo_movimiento = tipo_movimiento;
    }

    public cuenta_usuario getFk_cuenta_usuario() {
        return fk_cuenta_usuario;
    }

    public void setFk_cuenta_usuario(cuenta_usuario fk_cuenta_usuario) {
        this.fk_cuenta_usuario = fk_cuenta_usuario;
    }

    public Categoria getFk_categoria() {
        return fk_categoria;
    }

    public void setFk_categoria(Categoria fk_categoria) {
        this.fk_categoria = fk_categoria;
    }
}
