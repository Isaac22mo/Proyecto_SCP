package com.example.proyecto_spc.models.reporte;
import com.example.proyecto_spc.models.crud.DaoRepository;

import java.util.List;

public class DaoReporte implements DaoRepository<reporte> {
    @Override
    public List<reporte> findAll() {
        return null;
    }

    @Override
    public reporte findOne(Long id) {
        return null;
    }

    @Override
    public boolean save(reporte object) {
        return false;
    }

    @Override
    public boolean update(reporte object) {
        return false;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }
}
